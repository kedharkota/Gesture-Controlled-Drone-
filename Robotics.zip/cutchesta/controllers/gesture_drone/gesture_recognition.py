import cv2
import tensorflow as tf
import numpy as np
import time
from controller import Supervisor

# Load the gesture recognition mode
model = tf.keras.models.load_model(r"C:\Users\sai krishna\Desktop\robo\my_project\gesture_recognition_model2.h5")

# Define gesture mapping to interpret model predictions
gesture_mapping = {
    0: "eight",
    1: "five",
    2: "four",
    3: "nine",
    4: "one",
    5: "seven",
    6: "six",
    7: "ten",
    8: "three",
    9: "two",
}

# Map gestures to Webots commands
gesture_to_command = {
    "one": "up",
    "two": "down",
    "three": "left",
    "four": "right",
    "five": "rotate_left",
    "six": "rotate_right",
    "seven": "altitude_up",
    "eight": "altitude_down",
    # Add mappings as needed based on gestures and your desired commands
}

# Webots Supervisor instance
robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

# Initialize webcam
cap = cv2.VideoCapture(0)

def preprocess_frame(frame):
    """
    Preprocesses the webcam frame to the required model input size and normalizes it.
    Assumes the model expects a 64x64 RGB image.
    """
    frame = cv2.resize(frame, (64, 64))  # Resize to match model input
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert to RGB
    frame = frame / 255.0  # Normalize to [0, 1] range
    return np.expand_dims(frame, axis=0)  # Expand dimensions to match model input shape

def predict_gesture(frame):
    """
    Predicts the gesture based on the processed frame and returns the mapped command.
    """
    processed_frame = preprocess_frame(frame)
    prediction = model.predict(processed_frame)
    gesture_id = np.argmax(prediction)  # Get the gesture with the highest probability
    gesture_label = gesture_mapping.get(gesture_id, None)  # Map to label if exists
    return gesture_to_command.get(gesture_label, None)  # Return mapped command if valid

while robot.step(timestep) != -1:
    ret, frame = cap.read()
    if not ret:
        print("Failed to capture image")
        break

    gesture_command = predict_gesture(frame)
    if gesture_command:
        robot.wwiSendText(gesture_command)
        print(f"Sent command: {gesture_command}")

    # Small delay to control sending frequency
    time.sleep(0.1)

cap.release()
cv2.destroyAllWindows()
