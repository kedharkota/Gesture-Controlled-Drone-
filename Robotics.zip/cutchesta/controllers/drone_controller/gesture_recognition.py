import math
from controller import Robot, Motor, Camera, DistanceSensor, GPS, Gyro, InertialUnit
from pid_controller import init_pid_attitude_fixed_height_controller, pid_velocity_fixed_height_controller

# Constants
FLYING_ALTITUDE = 1.0

# Initialize the robot and get the timestep
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Initialize motors
m1_motor = robot.getDevice("m1_motor")
m1_motor.setPosition(float('inf'))
m1_motor.setVelocity(-1.0)

m2_motor = robot.getDevice("m2_motor")
m2_motor.setPosition(float('inf'))
m2_motor.setVelocity(1.0)

m3_motor = robot.getDevice("m3_motor")
m3_motor.setPosition(float('inf'))
m3_motor.setVelocity(-1.0)

m4_motor = robot.getDevice("m4_motor")
m4_motor.setPosition(float('inf'))
m4_motor.setVelocity(1.0)

# Initialize sensors
imu = robot.getDevice("inertial_unit")
imu.enable(timestep)

gps = robot.getDevice("gps")
gps.enable(timestep)

gyro = robot.getDevice("gyro")
gyro.enable(timestep)

camera = robot.getDevice("camera")
camera.enable(timestep)

range_front = robot.getDevice("range_front")
range_front.enable(timestep)
range_left = robot.getDevice("range_left")
range_left.enable(timestep)
range_back = robot.getDevice("range_back")
range_back.enable(timestep)
range_right = robot.getDevice("range_right")
range_right.enable(timestep)

# Wait for 2 seconds
while robot.step(timestep) != -1:
    if robot.getTime() > 2.0:
        break

# Initialize variables
actual_state = {
    "roll": 0,
    "pitch": 0,
    "yaw_rate": 0,
    "altitude": 0,
    "vx": 0,
    "vy": 0
}
desired_state = {
    "vx": 0,
    "vy": 0,
    "yaw_rate": 0,
    "altitude": FLYING_ALTITUDE
}
past_x_global = 0
past_y_global = 0
past_time = robot.getTime()

# Initialize PID gains
gains_pid = {
    "kp_att_y": 1,
    "kd_att_y": 0.5,
    "kp_att_rp": 0.5,
    "kd_att_rp": 0.1,
    "kp_vel_xy": 2,
    "kd_vel_xy": 0.5,
    "kp_z": 10,
    "ki_z": 5,
    "kd_z": 5
}
init_pid_attitude_fixed_height_controller()

# Motor power dictionary
motor_power = {"m1": 0, "m2": 0, "m3": 0, "m4": 0}

print("\n====== Gesture Control Initialized =======\n")

while robot.step(timestep) != -1:
    dt = robot.getTime() - past_time

    # Get measurements
    actual_state["roll"], actual_state["pitch"], _ = imu.getRollPitchYaw()
    actual_state["yaw_rate"] = gyro.getValues()[2]
    actual_state["altitude"] = gps.getValues()[2]
    x_global = gps.getValues()[0]
    vx_global = (x_global - past_x_global) / dt
    y_global = gps.getValues()[1]
    vy_global = (y_global - past_y_global) / dt

    # Get body-fixed velocities
    actual_yaw = imu.getRollPitchYaw()[2]
    cosyaw = math.cos(actual_yaw)
    sinyaw = math.sin(actual_yaw)
    actual_state["vx"] = vx_global * cosyaw + vy_global * sinyaw
    actual_state["vy"] = -vx_global * sinyaw + vy_global * cosyaw

    # Initialize movement variables
    forward_desired = 0
    sideways_desired = 0
    yaw_desired = 0
    height_diff_desired = 0

    # Receive gesture command from Python
    gesture_command = robot.wwiReceiveText()
    if gesture_command:
        if gesture_command == "up":
            forward_desired = 0.5
        elif gesture_command == "down":
            forward_desired = -0.5
        elif gesture_command == "right":
            sideways_desired = -0.5
        elif gesture_command == "left":
            sideways_desired = 0.5
        elif gesture_command == "rotate_right":
            yaw_desired = -1.0
        elif gesture_command == "rotate_left":
            yaw_desired = 1.0
        elif gesture_command == "altitude_up":
            height_diff_desired = 0.1
        elif gesture_command == "altitude_down":
            height_diff_desired = -0.1

    desired_state["altitude"] += height_diff_desired * dt
    desired_state["yaw_rate"] = yaw_desired
    desired_state["vy"] = sideways_desired
    desired_state["vx"] = forward_desired

    # PID velocity controller with fixed height
    pid_velocity_fixed_height_controller(actual_state, desired_state, gains_pid, dt, motor_power)

    # Set motor speeds
    m1_motor.setVelocity(-motor_power["m1"])
    m2_motor.setVelocity(motor_power["m2"])
    m3_motor.setVelocity(-motor_power["m3"])
    m4_motor.setVelocity(motor_power["m4"])

    # Save past time and positions for next timestep
    past_time = robot.getTime()
    past_x_global = x_global
    past_y_global = y_global

# Clean up robot resources
robot.cleanup()
