import tensorflow as tf
import numpy as np
from keras.models import load_model
import cv2
import time
import os
import logging
from controller import Robot, Motor, InertialUnit, GPS, Gyro, Camera, DistanceSensor

# ==============================
# Configuration and Setup
# ==============================

# Configure logging
logging.basicConfig(
    filename='gesture_drone_controller.log',
    level=logging.INFO,
    format='%(asctime)s:%(levelname)s:%(message)s'
)

# Define gesture mappings
gesture_mapping = {
    0: "eight",   # Hover
    1: "five",    # Land
    2: "four",    # Move Forward
    3: "nine",    # Move Backward
    4: "one",     # Move Left
    5: "seven",   # Move Right
    6: "six",     # Ascend
    7: "ten",     # Descend
    8: "three",   # Rotate Left
    9: "two",     # Rotate Right
}

# Map gestures to drone commands
gesture_to_command = {
    "eight": "Hover",
    "five": "Land",
    "four": "Move Forward",
    "nine": "Move Backward",
    "one": "Move Left",
    "seven": "Move Right",
    "six": "Ascend",
    "ten": "Descend",
    "three": "Rotate Left",
    "two": "Rotate Right",
}

# Path to the gesture recognition model (relative path)
MODEL_PATH = os.path.join(os.path.dirname(__file__), "gesture_recognition_model.h5")

# ==============================
# Initialize Robot and Devices
# ==============================

# Initialize the Robot instance
robot = Robot()

# Get the time step of the current world
timestep = int(robot.getBasicTimeStep())

# Initialize motors
m1_motor = robot.getMotor("m1_motor")
m2_motor = robot.getMotor("m2_motor")
m3_motor = robot.getMotor("m3_motor")
m4_motor = robot.getMotor("m4_motor")

# Set motors to velocity control mode
for motor in [m1_motor, m2_motor, m3_motor, m4_motor]:
    motor.setPosition(float('inf'))
    motor.setVelocity(0.0)

# Initialize sensors
imu = robot.getInertialUnit("inertial_unit")
imu.enable(timestep)

gps = robot.getGPS("gps")
gps.enable(timestep)

gyro = robot.getGyro("gyro")
gyro.enable(timestep)

camera = robot.getCamera("camera")
camera.enable(timestep)

range_front = robot.getDistanceSensor("range_front")
range_front.enable(timestep)

range_left = robot.getDistanceSensor("range_left")
range_left.enable(timestep)

range_back = robot.getDistanceSensor("range_back")
range_back.enable(timestep)

range_right = robot.getDistanceSensor("range_right")
range_right.enable(timestep)

# ==============================
# Load Gesture Recognition Model
# ==============================

def load_gesture_model(model_path):
    """Load the pre-trained gesture recognition model."""
    try:
        model = load_model(model_path)
        logging.info("Gesture recognition model loaded successfully.")
        return model
    except Exception as e:
        logging.error(f"Error loading gesture recognition model: {e}")
        exit(1)

model = load_gesture_model(MODEL_PATH)

# ==============================
# Initialize Video Capture
# ==============================

# Initialize video capture (webcam)
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    logging.error("Error: Could not open video capture.")
    exit(1)

# ==============================
# Define PID Controller Class
# ==============================

class PIDController:
    def __init__(self, kp, ki, kd):
        """Initialize PID controller with given gains."""
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0.0
        self.previous_error = 0.0

    def compute(self, error, dt):
        """Compute PID output."""
        if dt <= 0:
            derivative = 0.0
        else:
            derivative = (error - self.previous_error) / dt
        self.integral += error * dt
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.previous_error = error
        return output

# ==============================
# Initialize PID Controllers
# ==============================

# Define PID gains (these may need tuning based on your drone's behavior)
pid_vx = PIDController(kp=2.0, ki=0.0, kd=0.5)
pid_vy = PIDController(kp=2.0, ki=0.0, kd=0.5)
pid_z = PIDController(kp=10.0, ki=5.0, kd=5.0)
pid_yaw = PIDController(kp=1.0, ki=0.0, kd=0.5)

# Desired altitude
height_desired = 1.0  # Starting at 1 meter

# ==============================
# Preprocessing Function
# ==============================

def preprocess_frame(frame):
    """Preprocess the frame for model prediction."""
    frame = cv2.resize(frame, (224, 224))  # Adjust size based on your model's requirements
    frame = frame.astype('float32') / 255.0  # Normalize if required
    frame = np.expand_dims(frame, axis=0)    # Add batch dimension
    return frame

# ==============================
# Gesture Command Function
# ==============================

def get_gesture_command(model, frame):
    """Predict the gesture and return the corresponding command."""
    preprocessed = preprocess_frame(frame)
    prediction = model.predict(preprocessed)
    gesture_index = np.argmax(prediction)
    gesture_name = gesture_mapping.get(gesture_index, "eight")  # Default to "eight" (Hover) if unknown
    command = gesture_to_command.get(gesture_name, "Hover")
    return command

# ==============================
# Main Controller Loop
# ==============================

print("Starting gesture recognition and drone control.")

while robot.step(timestep) != -1:
    start_time = time.time()

    # Capture frame-by-frame
    ret, frame = cap.read()
    if not ret:
        logging.error("Failed to grab frame.")
        continue

    # Flip the frame horizontally for a mirror effect (optional)
    frame = cv2.flip(frame, 1)

    # Get the gesture command
    command = get_gesture_command(model, frame)
    logging.info(f"Recognized Command: {command}")

    # Get sensor data
    rpy = imu.getRollPitchYaw()  # Roll, Pitch, Yaw
    roll = rpy[0]
    pitch = rpy[1]
    yaw = rpy[2]

    altitude = gps.getValues()[2]
    vx_global = gps.getValues()[0]
    vy_global = gps.getValues()[1]
    vz_global = gps.getValues()[2]

    # Calculate velocities (simple differentiation)
    # For more accurate velocities, consider using the GPS velocity or IMU data
    # Here, we'll use placeholders as Webots doesn't provide direct velocity data
    # You may need to implement velocity calculation based on position over time

    # Initialize desired movements
    forward_desired = 0.0
    sideways_desired = 0.0
    yaw_desired = 0.0
    height_diff_desired = 0.0

    # Map gesture command to desired movements
    if command == "Hover":
        pass  # No movement
    elif command == "Land":
        height_diff_desired = -0.1
    elif command == "Move Forward":
        forward_desired = 0.5
    elif command == "Move Backward":
        forward_desired = -0.5
    elif command == "Move Left":
        sideways_desired = 0.5
    elif command == "Move Right":
        sideways_desired = -0.5
    elif command == "Ascend":
        height_diff_desired = 0.1
    elif command == "Descend":
        height_diff_desired = -0.1
    elif command == "Rotate Left":
        yaw_desired = 1.0
    elif command == "Rotate Right":
        yaw_desired = -1.0

    # Update desired altitude
    dt = time.time() - start_time
    height_desired += height_diff_desired * dt
    if height_desired < 0.0:
        height_desired = 0.0  # Prevent negative altitude

    # Compute PID outputs
    control_vx = pid_vx.compute(forward_desired - vx_global, dt)
    control_vy = pid_vy.compute(sideways_desired - vy_global, dt)
    control_z = pid_z.compute(height_desired - altitude, dt)
    control_yaw = pid_yaw.compute(yaw_desired - gyro.getValues()[2], dt)

    # Compute motor speeds based on PID outputs
    # Adjust these calculations based on your drone's configuration
    m1_speed = control_vx - control_vy + control_z - control_yaw
    m2_speed = control_vx + control_vy + control_z + control_yaw
    m3_speed = control_vx - control_vy + control_z - control_yaw
    m4_speed = control_vx + control_vy + control_z + control_yaw

    # Set motor speeds
    m1_motor.setVelocity(m1_speed)
    m2_motor.setVelocity(m2_speed)
    m3_motor.setVelocity(m3_speed)
    m4_motor.setVelocity(m4_speed)

    # Display the command on the frame for debugging
    cv2.putText(frame, f"Command: {command}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Gesture Control", frame)

    # Exit condition
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    # Optional: Add a small delay to control the loop's execution rate
    time.sleep(0.05)

# ==============================
# Cleanup
# ==============================

# Release video capture and close OpenCV windows
cap.release()
cv2.destroyAllWindows()

# Stop the robot
robot.cleanup()
