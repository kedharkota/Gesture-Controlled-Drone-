import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the CNN model
cnn_model = load_model("C:\\Users\\sai krishna\\Documents\\my_project\\roboticsn.h5")
labels = ['thumbsup', 'thumbsdown', 'ok', 'five', 'fist']

def process_gesture(roi):
    """
    Preprocess the input region of interest (ROI) and predict the gesture using the CNN model.
    """
    # Resize the ROI to the model's input size: (64, 64, 3)
    roi_resized = cv2.resize(roi, (64, 64))  # Keep it RGB
    roi_normalized = roi_resized.astype("float32") / 255.0  # Normalize pixel values
    roi_reshaped = np.expand_dims(roi_normalized, axis=0)  # Add batch dimension

    # Predict the gesture using the model
    prediction = cnn_model.predict(roi_reshaped)
    gesture_index = np.argmax(prediction)  # Get the index of the highest probability
    gesture_label = labels[gesture_index]  # Map the index to the gesture label

    return gesture_label

def main():
    # Initialize the video capture from the camera
    video_stream = cv2.VideoCapture(0)
    video_stream.set(cv2.CAP_PROP_FRAME_WIDTH, 600)
    video_stream.set(cv2.CAP_PROP_FRAME_HEIGHT, 800)

    # Coordinates of the box (Region of Interest)
    box_x, box_y, box_w, box_h = 200, 200, 200, 200  # Adjust these values as needed

    while True:
        # Capture frame-by-frame
        ret, frame = video_stream.read()
        if not ret:
            print("Failed to grab frame")
            break

        # Draw a bounding box where the hand is expected to be
        cv2.rectangle(frame, (box_x, box_y), (box_x + box_w, box_y + box_h), (255, 0, 0), 2)

        # Get the region of interest (ROI) from the frame inside the box
        roi = frame[box_y:box_y + box_h, box_x:box_x + box_w]

        # Process the gesture in the ROI
        gesture = process_gesture(roi)

        # Display the predicted gesture on the frame
        cv2.putText(frame, f'Gesture: {gesture}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
        cv2.imshow('Gesture Recognition', frame)

        # Press 'q' to exit the loop
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # When everything is done, release the capture and close windows
    video_stream.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
