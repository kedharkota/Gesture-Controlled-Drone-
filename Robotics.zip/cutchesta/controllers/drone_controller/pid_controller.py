import math

# Constrain function to limit values between a minimum and maximum
def constrain(value, min_val, max_val):
    return min(max(value, min_val), max_val)

# Initialize state variables for errors and integrators
past_altitude_error = 0.0
past_pitch_error = 0.0
past_roll_error = 0.0
past_yaw_rate_error = 0.0
past_vx_error = 0.0
past_vy_error = 0.0
altitude_integrator = 0.0

def init_pid_attitude_fixed_height_controller():
    global past_altitude_error, past_pitch_error, past_roll_error, past_yaw_rate_error
    global past_vx_error, past_vy_error, altitude_integrator
    past_altitude_error = 0.0
    past_pitch_error = 0.0
    past_roll_error = 0.0
    past_yaw_rate_error = 0.0
    past_vx_error = 0.0
    past_vy_error = 0.0
    altitude_integrator = 0.0

def pid_fixed_height_controller(actual_state, desired_state, gains_pid, dt, control_commands):
    global past_altitude_error, altitude_integrator
    altitude_error = desired_state['altitude'] - actual_state['altitude']
    altitude_derivative_error = (altitude_error - past_altitude_error) / dt
    altitude_integrator += altitude_error * dt
    
    control_commands['altitude'] = (
        gains_pid['kp_z'] * constrain(altitude_error, -1, 1) +
        gains_pid['kd_z'] * altitude_derivative_error +
        gains_pid['ki_z'] * altitude_integrator + 48
    )
    
    past_altitude_error = altitude_error

def motor_mixing(control_commands, motor_commands):
    motor_commands['m1'] = control_commands['altitude'] - control_commands['roll'] + control_commands['pitch'] + control_commands['yaw']
    motor_commands['m2'] = control_commands['altitude'] - control_commands['roll'] - control_commands['pitch'] - control_commands['yaw']
    motor_commands['m3'] = control_commands['altitude'] + control_commands['roll'] - control_commands['pitch'] + control_commands['yaw']
    motor_commands['m4'] = control_commands['altitude'] + control_commands['roll'] + control_commands['pitch'] - control_commands['yaw']

def pid_attitude_controller(actual_state, desired_state, gains_pid, dt, control_commands):
    global past_pitch_error, past_roll_error, past_yaw_rate_error
    pitch_error = desired_state['pitch'] - actual_state['pitch']
    pitch_derivative_error = (pitch_error - past_pitch_error) / dt
    roll_error = desired_state['roll'] - actual_state['roll']
    roll_derivative_error = (roll_error - past_roll_error) / dt
    yaw_rate_error = desired_state['yaw_rate'] - actual_state['yaw_rate']

    control_commands['roll'] = (
        gains_pid['kp_att_rp'] * constrain(roll_error, -1, 1) +
        gains_pid['kd_att_rp'] * roll_derivative_error
    )
    control_commands['pitch'] = (
        -gains_pid['kp_att_rp'] * constrain(pitch_error, -1, 1) -
        gains_pid['kd_att_rp'] * pitch_derivative_error
    )
    control_commands['yaw'] = gains_pid['kp_att_y'] * constrain(yaw_rate_error, -1, 1)

    past_pitch_error = pitch_error
    past_roll_error = roll_error
    past_yaw_rate_error = yaw_rate_error

def pid_horizontal_velocity_controller(actual_state, desired_state, gains_pid, dt):
    global past_vx_error, past_vy_error
    vx_error = desired_state['vx'] - actual_state['vx']
    vy_error = desired_state['vy'] - actual_state['vy']
    vx_derivative = (vx_error - past_vx_error) / dt
    vy_derivative = (vy_error - past_vy_error) / dt

    desired_state['pitch'] = (
        gains_pid['kp_vel_xy'] * constrain(vx_error, -1, 1) +
        gains_pid['kd_vel_xy'] * vx_derivative
    )
    desired_state['roll'] = (
        -gains_pid['kp_vel_xy'] * constrain(vy_error, -1, 1) -
        gains_pid['kd_vel_xy'] * vy_derivative
    )

    past_vx_error = vx_error
    past_vy_error = vy_error
