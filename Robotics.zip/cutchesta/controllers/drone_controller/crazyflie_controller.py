# crazyflie_controller.py

import math
import time
import cv2
import mediapipe as mp
import tensorflow as tf
import numpy as np
from controller import Robot, Motor, InertialUnit, GPS, Gyro, Camera, DistanceSensor
from pid_controller import PIDController

# =======================
# Configuration Parameters
# =======================

# Path to your TensorFlow gesture recognition model
MODEL_PATH = "C:/Users/sai krishna/Desktop/robo/my_project/gesture_recognition_model2.h5"

# Gesture to Command Mapping
gesture_mapping = {
    0: "one",     # Forward
    1: "two",     # Backward
    2: "three",   # Right
    3: "four",    # Left
    4: "five",    # Rotate Left
    5: "six",     # Rotate Right
    6: "seven",   # Ascend
    7: "eight",   # Descend
    8: "nine",    # Hover
    9: "ten",     # Land
}

# PID Gains Configuration
pid_gains = {
    'kp_z': 10.0, 'ki_z': 5.0, 'kd_z': 5.0,
    'kp_att_rp': 0.5, 'ki_att_rp': 0.0, 'kd_att_rp': 0.1,
    'kp_att_y': 1.0, 'ki_att_y': 0.0, 'kd_att_y': 0.5,
    'kp_vel_xy': 2.0, 'ki_vel_xy': 0.0, 'kd_vel_xy': 0.5
}

# Motor Names in Webots
motor_names = ["m1_motor", "m2_motor", "m3_motor", "m4_motor"]

# Command File Path
COMMAND_FILE = "C:/Users/sai krishna/Desktop/robo/my_project/command.txt"

# =======================
# Gesture Recognition Setup
# =======================

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.5
)
mp_drawing = mp.solutions.drawing_utils

# Load the gesture recognition model
try:
    gesture_model = tf.keras.models.load_model(MODEL_PATH)
    print("Gesture recognition model loaded successfully.")
except Exception as e:
    print(f"Error loading gesture recognition model: {e}")
    sys.exit()

# Open webcam
cap = cv2.VideoCapture(0)  # 0 is usually the default camera
if not cap.isOpened():
    print("Error: Cannot open webcam. Please check your webcam connection.")
    sys.exit()
else:
    print("Webcam opened successfully.")

# =======================
# PID Controller Initialization
# =======================

# Initialize PID controllers
pid_z = PIDController(kp=pid_gains['kp_z'], ki=pid_gains['ki_z'], kd=pid_gains['kd_z'], setpoint=1.0, output_limits=(0, 10))
pid_roll = PIDController(kp=pid_gains['kp_att_rp'], ki=pid_gains['ki_att_rp'], kd=pid_gains['kd_att_rp'], setpoint=0.0, output_limits=(-1, 1))
pid_pitch = PIDController(kp=pid_gains['kp_att_rp'], ki=pid_gains['ki_att_rp'], kd=pid_gains['kd_att_rp'], setpoint=0.0, output_limits=(-1, 1))
pid_yaw = PIDController(kp=pid_gains['kp_att_y'], ki=pid_gains['ki_att_y'], kd=pid_gains['kd_att_y'], setpoint=0.0, output_limits=(-1, 1))
pid_vx = PIDController(kp=pid_gains['kp_vel_xy'], ki=pid_gains['ki_vel_xy'], kd=pid_gains['kd_vel_xy'], setpoint=0.0, output_limits=(-1, 1))
pid_vy = PIDController(kp=pid_gains['kp_vel_xy'], ki=pid_gains['ki_vel_xy'], kd=pid_gains['kd_vel_xy'], setpoint=0.0, output_limits=(-1, 1))

# =======================
# Webots Robot and Devices Initialization
# =======================

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Initialize Motors
motors = {}
for name in motor_names:
    motor = robot.getDevice(name)
    if motor is None:
        print(f"Error: Motor '{name}' not found in the robot.")
        sys.exit()
    motor.setPosition(float('inf'))  # Velocity control mode
    motor.setVelocity(0)
    motors[name] = motor
print("Motors initialized successfully.")

# Initialize Sensors
imu = robot.getDevice("inertial_unit")
imu.enable(timestep)
gps = robot.getDevice("gps")
gps.enable(timestep)
gyro = robot.getDevice("gyro")
gyro.enable(timestep)
print("Sensors initialized successfully.")

# =======================
# Gesture to Command Mapping Function
# =======================

def get_gesture_command():
    ret, frame = cap.read()
    if not ret:
        print("Warning: Unable to capture video frame.")
        return "none"

    # Flip the frame horizontally for a mirror effect
    frame = cv2.flip(frame, 1)

    # Convert the frame to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process the frame to detect hand landmarks
    result = hands.process(rgb_frame)

    gesture = "none"

    if result.multi_hand_landmarks:
        # Extract the first hand's landmarks
        hand_landmarks = result.multi_hand_landmarks[0]

        # Draw landmarks on the frame for visualization
        mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Convert landmarks to a 1D array of 42 features (21 landmarks * 2 for x and y)
        landmarks = []
        for lm in hand_landmarks.landmark:
            landmarks.extend([lm.x, lm.y])  # Only x and y coordinates

        # Ensure we have the correct shape for the model input
        input_data = np.array(landmarks).reshape(1, -1).astype(np.float32)  # Shape (1, 42)

        # Run prediction on the model
        try:
            prediction = gesture_model.predict(input_data)
            gesture_id = prediction.argmax()
            gesture = gesture_mapping.get(gesture_id, "none")
            print(f"Recognized gesture: {gesture}")
        except Exception as e:
            print(f"Error during model prediction: {e}")
            gesture = "none"

        # Display the frame with landmarks and gesture name
        cv2.putText(frame, f"Gesture: {gesture}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.imshow("Webcam Feed", frame)
        cv2.waitKey(1)  # Needed to update the display window
    else:
        # Display a message indicating no hand detected
        cv2.putText(frame, "No hand detected", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (0, 0, 255), 2, cv2.LINE_AA)
        cv2.imshow("Webcam Feed", frame)
        cv2.waitKey(1)  # Needed to update the display window

    return gesture

# =======================
# Command File Writing Function
# =======================

def write_command_to_file(command):
    try:
        with open(COMMAND_FILE, "w") as file:
            file.write(command)
    except Exception as e:
        print(f"Error writing to command file: {e}")

# =======================
# Main Control Loop
# =======================

print("Starting Crazyflie controller with gesture recognition using webcam")

while robot.step(timestep) != -1:
    # Time difference
    current_time = robot.getTime()
    dt = current_time - past_time if current_time - past_time > 0 else 1e-3

    # Get sensor readings
    roll, pitch, yaw = imu.getRollPitchYaw()
    altitude = gps.getValues()[2]
    yaw_rate = gyro.getValues()[2]

    x_global = gps.getValues()[0]
    y_global = gps.getValues()[1]
    vx_global = (x_global - past_x_global) / dt
    vy_global = (y_global - past_y_global) / dt

    # Convert to body-fixed frame
    actualYaw = yaw
    cosyaw = math.cos(actualYaw)
    sinyaw = math.sin(actualYaw)

    vx = vx_global * cosyaw + vy_global * sinyaw
    vy = -vx_global * sinyaw + vy_global * cosyaw

    actual_state = {
        'roll': roll,
        'pitch': pitch,
        'yaw_rate': yaw_rate,
        'altitude': altitude,
        'vx': vx,
        'vy': vy
    }

    # Get gesture command
    gesture = get_gesture_command()

    # Initialize desired movement variables
    forward_desired = 0.0
    sideways_desired = 0.0
    yaw_desired = 0.0
    height_diff_desired = 0.0

    # Map gesture to desired movement
    if gesture == "one":     # Forward
        forward_desired = 0.5
    elif gesture == "two":    # Backward
        forward_desired = -0.5
    elif gesture == "three":  # Right
        sideways_desired = -0.5
    elif gesture == "four":   # Left
        sideways_desired = 0.5
    elif gesture == "five":   # Rotate Left
        yaw_desired = 1.0
    elif gesture == "six":    # Rotate Right
        yaw_desired = -1.0
    elif gesture == "seven":  # Ascend
        height_diff_desired = 0.1
    elif gesture == "eight":  # Descend
        height_diff_desired = -0.1
    elif gesture == "nine":   # Hover
        # Maintain current altitude and no movement
        forward_desired = 0.0
        sideways_desired = 0.0
        yaw_desired = 0.0
        height_diff_desired = 0.0
    elif gesture == "ten":    # Land
        height_diff_desired = -0.1
    else:
        # Unknown or no gesture detected
        forward_desired = 0.0
        sideways_desired = 0.0
        yaw_desired = 0.0
        height_diff_desired = 0.0

    # Update desired altitude based on height_diff_desired
    height_desired += height_diff_desired * dt

    desired_state = {
        'roll': 0.0,
        'pitch': 0.0,
        'yaw_rate': yaw_desired,
        'altitude': height_desired,
        'vx': forward_desired,
        'vy': sideways_desired
    }

    # Update PID setpoints
    pid_vx.setpoint = desired_state['vx']
    pid_vy.setpoint = desired_state['vy']
    pid_roll.setpoint = desired_state['roll']
    pid_pitch.setpoint = desired_state['pitch']
    pid_yaw.setpoint = desired_state['yaw_rate']
    pid_z.setpoint = desired_state['altitude']

    # Compute PID outputs
    control_vx = pid_vx.update(actual_state['vx'], dt)
    control_vy = pid_vy.update(actual_state['vy'], dt)
    control_roll = pid_roll.update(actual_state['roll'], dt)
    control_pitch = pid_pitch.update(actual_state['pitch'], dt)
    control_yaw = pid_yaw.update(actual_state['yaw_rate'], dt)
    control_z = pid_z.update(actual_state['altitude'], dt)

    # Combine control signals for motor mixing
    motor_power = {
        'm1_motor': control_z - control_roll + control_pitch + control_yaw,
        'm2_motor': control_z - control_roll - control_pitch - control_yaw,
        'm3_motor': control_z + control_roll - control_pitch + control_yaw,
        'm4_motor': control_z + control_roll + control_pitch - control_yaw
    }

    # Set motor velocities
    for name, power in motor_power.items():
        motors[name].setVelocity(power)

    # Debugging: Print desired and actual states and motor powers
    print(f"Gesture: {gesture}")
    print(f"Desired State: {desired_state}")
    print(f"Actual State: {actual_state}")
    print(f"Motor Power: {motor_power}\n")

    # Update past positions and time
    past_time = current_time
    past_x_global = x_global
    past_y_global = y_global

    # Write command to file
    write_command_to_file(gesture)

# Cleanup (unreachable in this loop but good practice)
cap.release()
hands.close()
cv2.destroyAllWindows()
print("Controller exited gracefully.")
