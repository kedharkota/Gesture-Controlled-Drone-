import tensorflow as tf
import cv2
import mediapipe as mp
import numpy as np
from controller import Robot

# Load model
model = tf.keras.models.load_model("C:\\Users\\Rishitha\\Downloads\\Robotics\\my_project\\my_project\\gesture_recognition_model.h5")

# Define gesture mapping dictionary
gesture_mapping = {
    0: "Fist",        # Hover
    1: "Five",        # Land
    2: "Peace",       # Move forward
    3: "Point_up",    # Ascend
    4: "ThumbsDown",  # Descend
    5: "ThumbsUp"     # Take off
}


# Webots robot setup
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Drone motors setup
motors = []
for motor_name in ["front left propeller", "front right propeller", "rear left propeller", "rear right propeller"]:
    motor = robot.getMotor(motor_name)
    if motor is None:
        print(f"Error: Motor {motor_name} not found!")  # Check for correct motor initialization
    motor.setPosition(float('inf'))
    motor.setVelocity(0)
    motors.append(motor)

# Drone movement functions
def set_motor_velocity(velocity):
    for motor in motors:
        motor.setVelocity(velocity)

def take_off():
    print("Take off")
    set_motor_velocity(15)  # Increased velocity for takeoff test

def land():
    print("Land")
    set_motor_velocity(0)

def ascend():
    print("Ascending")
    set_motor_velocity(10)

def descend():
    print("Descending")
    set_motor_velocity(5)

def move_forward():
    print("Moving forward")
    motors[0].setVelocity(8)  # Front left
    motors[1].setVelocity(8)  # Front right
    motors[2].setVelocity(10) # Rear left
    motors[3].setVelocity(10) # Rear right

def hover():
    print("Hovering")
    set_motor_velocity(7)

# Gesture recognition setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands()
cap = cv2.VideoCapture(0)

# Direct motor test: Uncomment this block to test motor control without gesture recognition
# while robot.step(timestep) != -1:
#     take_off()  # Replace with hover() or other functions to test motor response
#     robot.step(timestep)
# cap.release()
# exit()

# Main loop for Webots
while robot.step(timestep) != -1:
    ret, frame = cap.read()
    if not ret:
        break

    # Preprocess frame
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)

    # Predict gesture
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            landmarks = []
            for point in hand_landmarks.landmark:
                landmarks.append(point.x)
                landmarks.append(point.y)

            # Predict gesture
            landmarks = np.array([landmarks])
            prediction = model.predict(landmarks)
            gesture_label = np.argmax(prediction)
            gesture_name = gesture_mapping.get(gesture_label, "Unknown Gesture")

            # Print detected gesture and action
            print(f"Detected Gesture: {gesture_name}")

            # Drone control based on gesture
            if gesture_name == "Fist":
                hover()
            elif gesture_name == "Five":
                land()
            elif gesture_name == "Peace":
                move_forward()
            elif gesture_name == "Point_up":
                ascend()
            elif gesture_name == "ThumbsDown":
                descend()
            elif gesture_name == "ThumbsUp":
                take_off()

            # Display gesture name on the video feed
            cv2.putText(frame, f"Gesture: {gesture_name}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            

    # Display the video feed
    cv2.imshow("Real-Time Gesture Recognition", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # ESC to exit
        break

cap.release()
cv2.destroyAllWindows()
