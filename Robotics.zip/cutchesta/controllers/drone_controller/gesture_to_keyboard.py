# gesture_to_keyboard.py

import cv2
import mediapipe as mp
import tensorflow as tf
import numpy as np
import pyautogui
import time
import sys

# Load the gesture recognition model
MODEL_PATH = "C:\\Users\\sai krishna\\Desktop\\robo\\my_project\\gesture_recognition_model2.h5"
try:
    gesture_model = tf.keras.models.load_model(MODEL_PATH)
    print("Gesture recognition model loaded successfully.")
except Exception as e:
    print(f"Error loading model: {e}")
    sys.exit()

# Gesture mapping to keyboard keys
gesture_mapping = {
    0: "eight",   # Forward - Up Arrow
    1: "five",    # Backward - Down Arrow
    2: "four",    # Right - Right Arrow
    3: "nine",    # Left - Left Arrow
    4: "one",     # Rotate Left - 'Q' key
    5: "seven",   # Rotate Right - 'E' key
    6: "six",     # Ascend - 'W' key
    7: "ten",     # Descend - 'S' key
    8: "three",   # Hover - No action or maintain
    9: "two",     # Land - 'L' key (custom)
}

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False,
                       max_num_hands=1,
                       min_detection_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

# Open webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Cannot open webcam. Please check your webcam connection.")
    sys.exit()
else:
    print("Webcam opened successfully.")

# Function to interpret gesture commands
def get_gesture_command():
    ret, frame = cap.read()
    if not ret:
        print("Warning: Unable to capture video frame.")
        return None

    # Flip the frame horizontally for a mirror effect
    frame = cv2.flip(frame, 1)

    # Convert the frame to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process the frame to detect hand landmarks
    result = hands.process(rgb_frame)

    gesture = None

    if result.multi_hand_landmarks:
        # Extract the first hand's landmarks
        hand_landmarks = result.multi_hand_landmarks[0]

        # Draw landmarks on the frame for visualization
        mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Convert landmarks to a 1D array of 42 features (21 landmarks * 2 for x and y)
        landmarks = []
        for lm in hand_landmarks.landmark:
            landmarks.extend([lm.x, lm.y])  # Only x and y coordinates

        # Ensure we have the correct shape for the model input
        input_data = np.array(landmarks).reshape(1, -1).astype(np.float32)  # Shape (1, 42)

        # Run prediction on the model
        try:
            prediction = gesture_model.predict(input_data)
            gesture_id = prediction.argmax()
            gesture = gesture_mapping.get(gesture_id, "Unknown")
            print(f"Recognized gesture: {gesture}")
        except Exception as e:
            print(f"Error during model prediction: {e}")
            gesture = None

        # Display the frame with landmarks and gesture name
        cv2.putText(frame, f"Gesture: {gesture}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.imshow("Webcam Feed", frame)
        cv2.waitKey(1)  # Needed to update the display window
    else:
        # Display a message indicating no hand detected
        cv2.putText(frame, "No hand detected", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (0, 0, 255), 2, cv2.LINE_AA)
        cv2.imshow("Webcam Feed", frame)
        cv2.waitKey(1)  # Needed to update the display window

    return gesture

# Function to map gestures to keyboard keys
def map_gesture_to_key(gesture):
    if gesture == "eight":    # Forward
        pyautogui.press('up')
    elif gesture == "five":   # Backward
        pyautogui.press('down')
    elif gesture == "four":   # Right
        pyautogui.press('right')
    elif gesture == "nine":   # Left
        pyautogui.press('left')
    elif gesture == "one":    # Rotate Left
        pyautogui.press('q')
    elif gesture == "seven":  # Rotate Right
        pyautogui.press('e')
    elif gesture == "six":    # Ascend
        pyautogui.press('w')
    elif gesture == "ten":    # Descend
        pyautogui.press('s')
    elif gesture == "two":    # Land
        pyautogui.press('l')   # Custom key for landing
    elif gesture == "three":  # Hover
        pass  # No action or maintain current state
    else:
        pass  # Unknown gesture

# Main loop
try:
    print("Starting gesture to keyboard mapping. Press 'Ctrl+C' to exit.")
    while True:
        gesture = get_gesture_command()
        if gesture:
            map_gesture_to_key(gesture)
        # Add a small delay to prevent overwhelming the system
        time.sleep(0.5)
except KeyboardInterrupt:
    print("Gesture to keyboard mapping stopped by user.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    cap.release()
    hands.close()
    cv2.destroyAllWindows()
    print("Resources released.")
