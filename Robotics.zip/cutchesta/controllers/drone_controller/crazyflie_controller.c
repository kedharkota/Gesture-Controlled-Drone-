// crazyflie_controller.c

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <webots/camera.h>
#include <webots/distance_sensor.h>
#include <webots/gps.h>
#include <webots/gyro.h>
#include <webots/inertial_unit.h>
#include <webots/motor.h>
#include <webots/robot.h>

// Add external controller
#include "pid_controller.h"

#define FLYING_ALTITUDE 1.0
#define COMMAND_FILE "C:/Users/sai krishna/Desktop/robo/my_project/command.txt"  // Update the path as needed

int main(int argc, char **argv) {
  wb_robot_init();

  const int timestep = (int)wb_robot_get_basic_time_step();

  // Initialize motors
  WbDeviceTag m1_motor = wb_robot_get_device("m1_motor");
  wb_motor_set_position(m1_motor, INFINITY);
  wb_motor_set_velocity(m1_motor, -1.0);
  WbDeviceTag m2_motor = wb_robot_get_device("m2_motor");
  wb_motor_set_position(m2_motor, INFINITY);
  wb_motor_set_velocity(m2_motor, 1.0);
  WbDeviceTag m3_motor = wb_robot_get_device("m3_motor");
  wb_motor_set_position(m3_motor, INFINITY);
  wb_motor_set_velocity(m3_motor, -1.0);
  WbDeviceTag m4_motor = wb_robot_get_device("m4_motor");
  wb_motor_set_position(m4_motor, INFINITY);
  wb_motor_set_velocity(m4_motor, 1.0);

  // Initialize sensors
  WbDeviceTag imu = wb_robot_get_device("inertial_unit");
  wb_inertial_unit_enable(imu, timestep);
  WbDeviceTag gps = wb_robot_get_device("gps");
  wb_gps_enable(gps, timestep);
  WbDeviceTag gyro = wb_robot_get_device("gyro");
  wb_gyro_enable(gyro, timestep);
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, timestep);
  WbDeviceTag range_front = wb_robot_get_device("range_front");
  wb_distance_sensor_enable(range_front, timestep);
  WbDeviceTag range_left = wb_robot_get_device("range_left");
  wb_distance_sensor_enable(range_left, timestep);
  WbDeviceTag range_back = wb_robot_get_device("range_back");
  wb_distance_sensor_enable(range_back, timestep);
  WbDeviceTag range_right = wb_robot_get_device("range_right");
  wb_distance_sensor_enable(range_right, timestep);

  // Wait for 2 seconds
  while (wb_robot_step(timestep) != -1) {
    if (wb_robot_get_time() > 2.0)
      break;
  }

  // Initialize variables
  actual_state_t actual_state = {0};
  desired_state_t desired_state = {0};
  double past_x_global = 0;
  double past_y_global = 0;
  double past_time = wb_robot_get_time();

  // Initialize PID gains.
  gains_pid_t gains_pid;
  gains_pid.kp_att_y = 1;
  gains_pid.kd_att_y = 0.5;
  gains_pid.kp_att_rp = 0.5;
  gains_pid.kd_att_rp = 0.1;
  gains_pid.kp_vel_xy = 2;
  gains_pid.kd_vel_xy = 0.5;
  gains_pid.kp_z = 10;
  gains_pid.ki_z = 5;
  gains_pid.kd_z = 5;
  init_pid_attitude_fixed_height_controller();

  double height_desired = FLYING_ALTITUDE;

  // Initialize struct for motor power
  motor_power_t motor_power;

  printf("\n");

  printf("====== Controls =======\n");

  printf(" The Crazyflie can be controlled via gestures!\n");
  printf(" All controllable movement is in body coordinates\n");
  printf("- Show 'eight' gesture to move forward\n");
  printf("- Show 'five' gesture to move backward\n");
  printf("- Show 'four' gesture to move right\n");
  printf("- Show 'nine' gesture to move left\n");
  printf("- Show 'one' gesture to rotate left\n");
  printf("- Show 'seven' gesture to rotate right\n");
  printf("- Show 'six' gesture to ascend\n");
  printf("- Show 'ten' gesture to descend\n");
  printf("- Show 'three' gesture to hover\n");
  printf("- Show 'two' gesture to land\n");

  // Function to read command from file
  void read_command(char *command_buffer, size_t size) {
    FILE *file = fopen(COMMAND_FILE, "r");
    if (file == NULL) {
      printf("Error: Unable to open command file.\n");
      strcpy(command_buffer, "none");
      return;
    }
    if (fgets(command_buffer, size, file) == NULL) {
      strcpy(command_buffer, "none");
    }
    fclose(file);
  }

  while (wb_robot_step(timestep) != -1) {
    const double dt = wb_robot_get_time() - past_time;

    // Read the command from the file
    char command[50];
    read_command(command, sizeof(command));

    // Initialize desired movement variables
    double forward_desired = 0;
    double sideways_desired = 0;
    double yaw_desired = 0;
    double height_diff_desired = 0;

    // Map the command to movement variables
    if (strcmp(command, "eight") == 0) {  // Forward
      forward_desired = 0.5;
    }
    else if (strcmp(command, "five") == 0) {  // Backward
      forward_desired = -0.5;
    }
    else if (strcmp(command, "four") == 0) {  // Right
      sideways_desired = -0.5;
    }
    else if (strcmp(command, "nine") == 0) {  // Left
      sideways_desired = 0.5;
    }
    else if (strcmp(command, "one") == 0) {  // Rotate Left
      yaw_desired = 1.0;
    }
    else if (strcmp(command, "seven") == 0) {  // Rotate Right
      yaw_desired = -1.0;
    }
    else if (strcmp(command, "six") == 0) {  // Ascend
      height_diff_desired = 0.1;
    }
    else if (strcmp(command, "ten") == 0) {  // Descend
      height_diff_desired = -0.1;
    }
    else if (strcmp(command, "three") == 0) {  // Hover
      // Maintain current altitude and no movement
      forward_desired = 0;
      sideways_desired = 0;
      yaw_desired = 0;
      height_diff_desired = 0;
    }
    else if (strcmp(command, "two") == 0) {  // Land
      // Set height_diff_desired to descend
      forward_desired = 0;
      sideways_desired = 0;
      yaw_desired = 0;
      height_diff_desired = -0.1;
    }
    else {
      // Unknown or no command
      forward_desired = 0;
      sideways_desired = 0;
      yaw_desired = 0;
      height_diff_desired = 0;
    }

    // Update desired altitude based on height_diff_desired
    height_desired += height_diff_desired * dt;

    // Get measurements
    actual_state.roll = wb_inertial_unit_get_roll_pitch_yaw(imu)[0];
    actual_state.pitch = wb_inertial_unit_get_roll_pitch_yaw(imu)[1];
    actual_state.yaw_rate = wb_gyro_get_values(gyro)[2];
    actual_state.altitude = wb_gps_get_values(gps)[2];
    double x_global = wb_gps_get_values(gps)[0];
    double vx_global = (x_global - past_x_global) / dt;
    double y_global = wb_gps_get_values(gps)[1];
    double vy_global = (y_global - past_y_global) / dt;

    // Get body fixed velocities
    double actualYaw = wb_inertial_unit_get_roll_pitch_yaw(imu)[2];
    double cosyaw = cos(actualYaw);
    double sinyaw = sin(actualYaw);
    actual_state.vx = vx_global * cosyaw + vy_global * sinyaw;
    actual_state.vy = -vx_global * sinyaw + vy_global * cosyaw;

    // Update past positions and time
    past_x_global = x_global;
    past_y_global = y_global;
    past_time = wb_robot_get_time();

    // Desired state
    desired_state.roll = 0;
    desired_state.pitch = 0;
    desired_state.yaw_rate = yaw_desired;
    desired_state.altitude = height_desired;
    desired_state.vx = forward_desired;
    desired_state.vy = sideways_desired;

    // PID velocity controller with fixed height
    pid_velocity_fixed_height_controller(actual_state, &desired_state, gains_pid, dt, &motor_power);

    // Setting motor speeds
    wb_motor_set_velocity(m1_motor, -motor_power.m1);
    wb_motor_set_velocity(m2_motor, motor_power.m2);
    wb_motor_set_velocity(m3_motor, -motor_power.m3);
    wb_motor_set_velocity(m4_motor, motor_power.m4);

    // Debugging: Print the command and motor powers
    printf("Command: %s\n", command);
    printf("Desired State: Roll=%.2f, Pitch=%.2f, Yaw Rate=%.2f, Altitude=%.2f, Vx=%.2f, Vy=%.2f\n",
           desired_state.roll, desired_state.pitch, desired_state.yaw_rate,
           desired_state.altitude, desired_state.vx, desired_state.vy);
    printf("Motor Power: m1=%.2f, m2=%.2f, m3=%.2f, m4=%.2f\n",
           motor_power.m1, motor_power.m2, motor_power.m3, motor_power.m4);
  }

  wb_robot_cleanup();

  return 0;
}
