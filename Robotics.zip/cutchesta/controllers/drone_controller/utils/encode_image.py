# encode_image.py
import base64
import numpy as np
from controller import Camera

def encode_image(image_bytes):
    """Encodes Webots image bytes to a base64 string."""
    return base64.b64encode(image_bytes).decode('utf-8')
