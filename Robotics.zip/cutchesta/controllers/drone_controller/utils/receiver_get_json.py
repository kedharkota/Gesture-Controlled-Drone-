# receiver_get_json.py
import json
from controller import Receiver

def receiver_get_json(receiver: Receiver):
    """Receives JSON data from a Receiver device."""
    while receiver.getQueueLength() > 0:
        message = receiver.getData().decode('utf-8')
        receiver.nextPacket()
        try:
            data = json.loads(message)
            return data, message
        except json.JSONDecodeError:
            print("Error decoding JSON message.")
    return {}, ""
