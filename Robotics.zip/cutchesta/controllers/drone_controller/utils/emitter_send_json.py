# emitter_send_json.py
import json
from controller import Emitter

def emitter_send_json(emitter: Emitter, data: dict):
    """Sends JSON data through an Emitter device."""
    message = json.dumps(data)
    emitter.send(bytes(message, 'utf-8'))
