from controller import Robot
from pid_controller import (
    init_pid_attitude_fixed_height_controller,
    pid_fixed_height_controller,
    pid_attitude_controller,
    pid_horizontal_velocity_controller,
    motor_mixing
)
import cv2
import numpy as np
import math
import tensorflow as tf
import mediapipe as mp
import threading

# Initialize Webots Robot and timestep
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Initialize Motors
m1_motor = robot.getDevice("m1_motor")  # Motor 1 (CW)
m2_motor = robot.getDevice("m2_motor")  # Motor 2 (CCW)
m3_motor = robot.getDevice("m3_motor")  # Motor 3 (CW)
m4_motor = robot.getDevice("m4_motor")  # Motor 4 (CCW)
for motor in [m1_motor, m2_motor, m3_motor, m4_motor]:
    motor.setPosition(float('inf'))
    motor.setVelocity(0)

# Initialize Sensors
imu = robot.getDevice("inertial_unit")
imu.enable(timestep)
gps = robot.getDevice("gps")
gps.enable(timestep)
gyro = robot.getDevice("gyro")
gyro.enable(timestep)

# PID gain values
gains_pid = {
    'kp_att_y': 1,
    'kd_att_y': 0.5,
    'kp_att_rp': 0.5,
    'kd_att_rp': 0.1,
    'kp_vel_xy': 2,
    'kd_vel_xy': 0.5,
    'kp_z': 10,
    'ki_z': 5,
    'kd_z': 5
}

# Load Gesture Recognition Model
model_path = "C:\\SEM-3\\Robotics\\Projects\\Robotics\\cutchesta\\gesture_recognition_model2.h5"
gesture_model = tf.keras.models.load_model(model_path)

# Gesture mapping and action mappings
gesture_mapping = {
    0: "eight",    # Forward
    1: "five",     # Backward
    2: "four",     # Left
    3: "nine",     # Right
    4: "one",      # Yaw left
    5: "seven",    # Yaw right
    6: "six",      # Increase altitude
    7: "ten",      # Decrease altitude
    8: "three",    # Hover (stop)
    9: "two"       # Emergency stop or hover
}

action_mapping = {
    "eight": "UP",
    "five": "DOWN",
    "four": "LEFT",
    "nine": "RIGHT",
    "one": "Q",    # Yaw left
    "seven": "E",  # Yaw right
    "six": "W",    # Increase altitude
    "ten": "S",    # Decrease altitude
    "three": None, # Hover
    "two": None    # Emergency stop / hover
}

# Initialize PID and command queue
init_pid_attitude_fixed_height_controller()
height_desired = 1.0
command_queue = []

# Initialize Mediapipe for hand tracking
mp_hands = mp.solutions.hands
hands = mp_hands.Hands()

# Gesture control function
def gesture_control():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open camera.")
        return
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break
        
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        # If hand landmarks are detected, process them
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                landmarks = []
                for point in hand_landmarks.landmark:
                    landmarks.extend([point.x, point.y])  # Collect x, y points
                
                # Prepare landmarks for model input and predict gesture
                landmarks = np.array([landmarks])
                prediction = gesture_model.predict(landmarks)
                gesture_label = np.argmax(prediction)
                gesture_name = gesture_mapping.get(gesture_label, "Unknown Gesture")
                action = action_mapping.get(gesture_name)

                # Add action to command queue if valid
                if action:
                    command_queue.append(action)

                # Display detected gesture and action on the video feed
                cv2.putText(frame, f"Gesture: {gesture_name}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                cv2.putText(frame, f"Action: {action or 'Hover'}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        cv2.imshow("Real-Time Gesture Recognition with Actions", frame)

        # Exit gesture control if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

# Run gesture recognition in a separate thread
gesture_thread = threading.Thread(target=gesture_control)
gesture_thread.start()

# Variables for past time and position
past_x_global = 0.0
past_y_global = 0.0
past_time = robot.getTime()

# Main control loop for Webots
while robot.step(timestep) != -1:
    dt = robot.getTime() - past_time

    # Get current state from sensors
    actual_state = {
        'roll': imu.getRollPitchYaw()[0],
        'pitch': imu.getRollPitchYaw()[1],
        'yaw_rate': gyro.getValues()[2],
        'altitude': gps.getValues()[2]
    }
    x_global = gps.getValues()[0]
    y_global = gps.getValues()[1]
    vx_global = (x_global - past_x_global) / dt
    vy_global = (y_global - past_y_global) / dt

    # Compute body-fixed velocities
    actual_yaw = imu.getRollPitchYaw()[2]
    cosyaw, sinyaw = math.cos(actual_yaw), math.sin(actual_yaw)
    actual_state['vx'] = vx_global * cosyaw + vy_global * sinyaw
    actual_state['vy'] = -vx_global * sinyaw + vy_global * cosyaw

    # Initialize desired state
    desired_state = {
        'roll': 0,
        'pitch': 0,
        'vx': 0,
        'vy': 0,
        'yaw_rate': 0,
        'altitude': height_desired
    }

    # Check for commands from gesture control
    if command_queue:
        command = command_queue.pop(0)
        if command == "UP": desired_state['vx'] = 6  # Increased for faster response
        elif command == "DOWN": desired_state['vx'] = -6
        elif command == "LEFT": desired_state['vy'] = 6
        elif command == "RIGHT": desired_state['vy'] = -6
        elif command == "Q": desired_state['yaw_rate'] = 10  # Increased yaw sensitivity
        elif command == "E": desired_state['yaw_rate'] = -10
        elif command == "W": height_desired += 0.07  # Decreased altitude sensitivity
        elif command == "S": height_desired -= 0.07
        elif command is None:
            # Hover or stop command
            desired_state['vx'] = 0
            desired_state['vy'] = 0
            desired_state['yaw_rate'] = 0

    # Update the desired altitude
    desired_state['altitude'] = height_desired

    # Control commands and motor power dictionary
    control_commands = {'altitude': 0, 'roll': 0, 'pitch': 0, 'yaw': 0}
    motor_power = {'m1': 0, 'm2': 0, 'm3': 0, 'm4': 0}

    # Apply PID controllers
    pid_horizontal_velocity_controller(actual_state, desired_state, gains_pid, dt)
    pid_fixed_height_controller(actual_state, desired_state, gains_pid, dt, control_commands)
    pid_attitude_controller(actual_state, desired_state, gains_pid, dt, control_commands)

    # Calculate motor power based on control commands
    motor_mixing(control_commands, motor_power)

    # Set motor velocities with correct directional clamping
    m1_motor.setVelocity(max(-600, min(-motor_power['m1'], 600)))  # Motor 1 (CW)
    m2_motor.setVelocity(max(-600, min(motor_power['m2'], 600)))   # Motor 2 (CCW)
    m3_motor.setVelocity(max(-600, min(-motor_power['m3'], 600)))  # Motor 3 (CW)
    m4_motor.setVelocity(max(-600, min(motor_power['m4'], 600)))   # Motor 4 (CCW)

    # Update past variables for the next loop
    past_time = robot.getTime()
    past_x_global = x_global
    past_y_global = y_global

# Cleanup when the simulation ends
gesture_thread.join()
robot.cleanup()
