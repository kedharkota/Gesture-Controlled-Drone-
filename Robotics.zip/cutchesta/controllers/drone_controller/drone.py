# drone.py
import numpy as np
from controller import Robot, Motor, Compass, GPS, Gyro, InertialUnit, DistanceSensor, LED, Camera

class Drone:
    """The Drone class manages each sensor and actuator of the drone."""

    def __init__(self, robot):
        self.robot = robot

        # Initialize Motors
        self.motors = {}
        motor_names = ["front left propeller", "front right propeller", "rear left propeller", "rear right propeller"]
        for name in motor_names:
            motor = self.robot.getDevice(name)
            if motor is not None:
                motor.setPosition(float('inf'))
                motor.setVelocity(0.0)
                self.motors[name] = motor
            else:
                print(f"Warning: Motor '{name}' not found.")

        # Initialize Sensors
        self.compass = self.robot.getDevice("Compass")
        if self.compass is not None:
            self.compass.enable(int(robot.getBasicTimeStep()))
        else:
            print("Warning: Compass not found.")

        self.gps = self.robot.getDevice("GPS")
        if self.gps is not None:
            self.gps.enable(int(robot.getBasicTimeStep()))
        else:
            print("Warning: GPS not found.")

        self.gyro = self.robot.getDevice("Gyro")
        if self.gyro is not None:
            self.gyro.enable(int(robot.getBasicTimeStep()))
        else:
            print("Warning: Gyro not found.")

        self.imu = self.robot.getDevice("InertialUnit")
        if self.imu is not None:
            self.imu.enable(int(robot.getBasicTimeStep()))
        else:
            print("Warning: InertialUnit not found.")

        # Initialize Distance Sensors
        self.distance_sensors = {}
        distance_sensor_names = [
            'front left dist sonar',
            'front right dist sonar',
            'rear top dist sonar',
            'rear bottom dist sonar',
            'left side dist sonar',
            'right side dist sonar',
            'down front dist sonar',
            'down back dist sonar',
            'top dist infrared'
        ]
        for name in distance_sensor_names:
            sensor = self.robot.getDevice(name)
            if sensor is not None:
                sensor.enable(int(robot.getBasicTimeStep()))
                self.distance_sensors[name] = sensor
            else:
                print(f"Warning: Distance sensor '{name}' not found.")

        # Initialize LEDs
        self.leds = {}
        led_names = ["front left led", "front right led"]
        for name in led_names:
            led = self.robot.getDevice(name)
            if led is not None:
                self.leds[name] = led
            else:
                print(f"Warning: LED '{name}' not found.")

        # Initialize Camera
        self.camera = self.robot.getDevice("camera")
        if self.camera is not None:
            self.camera.enable(1000 // 25)  # 25 FPS
        else:
            print("Warning: Camera not found.")

        # Initialize Gimbal Motors (Yaw, Pitch, Roll)
        self.camera_yaw = self.robot.getDevice("camera yaw")
        if self.camera_yaw is not None:
            self.camera_yaw.setPosition(float('inf'))
            self.camera_yaw.setVelocity(0.0)
        else:
            print("Warning: Camera Yaw Motor not found.")

        self.camera_pitch = self.robot.getDevice("camera pitch")
        if self.camera_pitch is not None:
            self.camera_pitch.setPosition(float('inf'))
            self.camera_pitch.setVelocity(0.0)
        else:
            print("Warning: Camera Pitch Motor not found.")

        self.camera_roll = self.robot.getDevice("camera roll")
        if self.camera_roll is not None:
            self.camera_roll.setPosition(float('inf'))
            self.camera_roll.setVelocity(0.0)
        else:
            print("Warning: Camera Roll Motor not found.")

    def get_odometry(self):
        """Get the drone's current orientation, angular velocity, position, speed, and north direction."""
        orientation = self.imu.getRollPitchYaw() if self.imu is not None else [0.0, 0.0, 0.0]
        angular_velocity = self.gyro.getValues() if self.gyro is not None else [0.0, 0.0, 0.0]
        position = self.gps.getValues() if self.gps is not None else [0.0, 0.0, 0.0]
        speed = self.gps.getSpeedVector() if self.gps is not None else [0.0, 0.0, 0.0]
        compass_values = self.compass.getValues() if self.compass is not None else [0.0, 0.0, 0.0]
        north_rad = np.arctan2(compass_values[0], compass_values[1]) if self.compass is not None else 0.0
        north_rad = self.orientation_correction(north_rad)
        return orientation, angular_velocity, position, speed, north_rad

    def orientation_correction(self, north_rad):
        """Correct orientation based on compass data."""
        # Implement any necessary correction here
        return north_rad

    def get_dist_sensors(self):
        """Get the current readings from all distance sensors."""
        sensors = {}
        for name, sensor in self.distance_sensors.items():
            sensors[name] = [sensor.getValue(), sensor.getMinValue(), sensor.getMaxValue()]
        return sensors

    def get_image(self):
        """Get the current image from the camera."""
        if self.camera is not None:
            image = self.camera.getImage()
            if image:
                return image  # You might want to process the image as needed
        return None

    def set_motors_velocity(self, fl_motor, fr_motor, rl_motor, rr_motor):
        """Set the velocities of all propeller motors."""
        motor_names = ["front left propeller", "front right propeller", "rear left propeller", "rear right propeller"]
        velocities = [fl_motor, fr_motor, rl_motor, rr_motor]
        for name, velocity in zip(motor_names, velocities):
            motor = self.motors.get(name)
            if motor is not None:
                motor.setVelocity(velocity)
            else:
                print(f"Error: Motor '{name}' not initialized.")

    def blink_leds(self):
        """Blink the LEDs to indicate status."""
        # Example implementation: toggle LEDs on and off
        # Implement your own blinking logic based on time or state
        for led in self.leds.values():
            current_value = led.get()
            led.set(not current_value)

    def gimbal_stabilize(self):
        """Stabilize the camera gimbal based on gyro data."""
        # Implement gimbal stabilization logic if needed
        pass
